app.factory("config", function() {
    return{
        servicio: 'http://localhost/servicios/public/',
        intervaloTarea: 10
    }
});